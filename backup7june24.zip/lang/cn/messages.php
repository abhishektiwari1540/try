<?php return array("website_signup"=>"注册",
);