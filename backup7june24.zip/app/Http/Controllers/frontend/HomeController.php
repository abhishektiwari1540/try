<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Redirect, Session, Config;

class HomeController extends Controller
{


    public function index(Request $request)
    {
        return view('frontend.index');
    }



    public function classes(Request $request){
        return view('frontend.classes');
    }


    public function events(Request $request){
        return view('frontend.events');
    }


    public function about(Request $request){
        return view('frontend.about-us');
    }

    public function contact(Request $request){
        return view('frontend.contact');
    }


    public function yoga_darshan(Request $request){
        return view('frontend.yoga-darshan');
    }


    public function yoga_aahaar(Request $request){
        return view('frontend.yoga-for-aahaar');
    }


    public function yoga_bahiranga(Request $request){
       return view('frontend.yoga-of-bahiranga');
    }


    public function yoga_breathing(Request $request){
        return view('frontend.yoga-of-breathing');
    }

    public function yoga_health_system(Request $request){
        return view('frontend.yoga-of-health-systems');
    }


    public function yoga_intellect(Request $request){
        return view('frontend.yoga-of-mind-and-intellect');
    }


    public function login(Request $request){
        return view('frontend.Auth.login');
    }

    public function register(Request $request){
        return view('frontend.Auth.register');
    }

    public function privacy_policy(Request $request){
        return view('frontend.privacy-policy');
    }

    public function Refund_policy(Request $request){
        return view('frontend.refund-policy');
    }


    public function thank_you(Request $request){
        return view('frontend.thank-you');
    }

    public function suprabha_jain(Request $request){
        return view('frontend.suprabha-jain');
    }


    public function invoice(Request $request){
        return view('frontend.invoice');
    }


    public function checkout_classes(Request $request){
        return view('frontend.checkout-classes');
    }

    public function elements(Request $request){
        return view('frontend.elements');
    }

}
