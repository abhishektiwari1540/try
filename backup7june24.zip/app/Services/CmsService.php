<?php

namespace App\Services;

use App\Models\Security;
use App\Models\Lookup;
use App\Models\Faq;
use App\Models\Language;

class CmsService
{
	public function security() {
		return Security::leftJoin('security_description', 'security.id', '=', 'security_description.parent_id')
        ->where('security_description.language_id', currentLanguageId())
        ->select('security_description.title', 'security_description.description', 'security.image')
        ->get();
    }

    public function lookups($name='') {
        return Lookup::leftJoin('lookup_discriptions', 'lookups.id', '=', 'lookup_discriptions.parent_id')
        ->where('lookup_discriptions.language_id', currentLanguageId())
        ->where('lookups.lookup_type',$name)
        ->where('lookups.is_active',1)
        ->select('lookup_discriptions.code', 'lookups.id')
        ->get();
    }

    public function helpSupport() {
        return Faq::leftJoin('faq_descriptions', 'faqs.id', '=', 'faq_descriptions.parent_id')
        ->where('faq_descriptions.language_id', currentLanguageId())
        ->select('faq_descriptions.question', 'faq_descriptions.answer')
        ->get();
    }

    public function languages() {
        return Language::where('is_active',1)->get();
    }
}