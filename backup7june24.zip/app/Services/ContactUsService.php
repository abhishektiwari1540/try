<?php

namespace App\Services;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Models\EmailTemplate;
use App\Models\EmailAction;
use App\Models\ContactUs;
use Redirect,Session,Config;

class ContactUsService
{
               public function index(Request $request){
                $result = [];
                $DB							=	ContactUs::query();
                $searchVariable = array();
                   $inputGet = $request->all();
                   if ($request->all()) {
                       $searchData = $request->all();
                       unset($searchData['display']);
                       unset($searchData['_token']);

                       if (isset($searchData['order'])) {
                           unset($searchData['order']);
                       }
                       if (isset($searchData['sortBy'])) {
                           unset($searchData['sortBy']);
                       }
                       if (isset($searchData['page'])) {
                           unset($searchData['page']);
                       }

                       foreach ($searchData as $fieldName => $fieldValue) {
                           if ($fieldValue != "") {
                               if ($fieldName == "title") {
                                   $DB->where("seo_pages.title", 'like', '%' . $fieldValue . '%');
                               }

                           }
                           $searchVariable = array_merge($searchVariable, array($fieldName => $fieldValue));
                       }
                   }
                   $DB->where('is_deleted',0);
                   $sortBy = ($request->input('sortBy')) ? $request->input('sortBy') : 'created_at';
                   $order = ($request->input('order')) ? $request->input('order') : 'DESC';
                   $records_per_page = ($request->input('per_page')) ? $request->input('per_page') : Config::get("Reading.records_per_page");
                   $results = $DB->orderBy($sortBy, $order)->paginate($records_per_page);
                   $complete_string = $request->query();
                   unset($complete_string["sortBy"]);
                   unset($complete_string["order"]);
                   $query_string = http_build_query($complete_string);
                   $results->appends($inputGet)->render();

                   $result = ['status' => true, 'results' => $results, 'searchVariable' => $searchVariable, 'sortBy' => $sortBy , 'order' => $order, 'query_string' => $query_string];
                   return $result;
               }



}
