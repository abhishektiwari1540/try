<?php 
config(["Contact.admin_email"=>"admin@gmail.com"]);
config(["Contact.CompanyName"=>"Wildtag"]);
config(["Contact.email_address"=>"wildtag.help@gmail.com"]);
config(["Contact.footer_text"=>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."]);
config(["Reading.date_format"=>"m-d-Y"]);
config(["Reading.records_per_page"=>"10"]);
config(["Site.from_email"=>"team@im.owebest.com"]);
config(["Site.right"=>"© Copyright. 2024 Yoga meditation plus"]);
config(["Site.title"=>"Yoga meditation plus"]);
config(["Social.facebook"=>"https://www.facebook.com"]);
config(["Social.instagram"=>"https://www.instagram.com"]);
config(["Social.twitter"=>"https://twitter.com"]);
