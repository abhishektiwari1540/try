<?php 
config(["contact.address"=>"Jaipur"]);
config(["Contact.admin_email"=>"admin@gmail.com"]);
config(["Contact.email_address"=>"yogameditationplus@gmail.com"]);
config(["Contact.phone"=>"9554696546"]);
config(["Reading.date_format"=>"m-d-Y"]);
config(["Reading.date_time_format"=>"m-d-Y h:i A"]);
config(["Reading.records_per_page"=>"10"]);
config(["Site.from_email"=>"team@im.owebest.com"]);
config(["Site.right"=>"© 2024 Yoga Meditation Plus"]);
config(["Site.title"=>"Yoga Meditation plus"]);
config(["Social.facebook"=>"https://www.facebook.com"]);
config(["Social.instagram"=>"https://www.instagram.com/"]);
config(["Social.linkedin"=>"https://www.linkedin.com"]);
config(["Social.pinterest"=>"https://www.pinterest.com/"]);
config(["Social.twitter"=>"https://twitter.com/"]);
config(["Social.youtube"=>"https://www.youtube.com/"]);
