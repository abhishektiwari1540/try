<?php 
namespace App\Models; 
use Eloquent;
/**
 * Review Model
 */
class SeoPage extends Eloquent {

	
/**
 * The database table used by the model.
 *
 * @var string
 */
	protected $table = 'seo_pages';
	
}// end EmailAction class
